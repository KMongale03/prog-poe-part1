package com.mycompany.loginregistrationapp;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
import java.util.Scanner;

public class LoginRegistrationApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=== User Registration ===");

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter cell phone number (with +27): ");
        String cellPhoneNumber = scanner.nextLine();

        String registrationResult = login.registerUser(username, password, cellPhoneNumber,
                firstName, lastName);
        System.out.println(registrationResult);

        // Only attempt login if registration succeeded
        if (registrationResult.equals("User successfully registered.")) {
            System.out.println("\n=== Login ===");

            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();

            login.loginUser(loginUsername, loginPassword);
            System.out.println(login.returnLoginStatus());
        }

        scanner.close();
    }
}