/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package User;

/**
 *
 * @author Student
 */
/**
 * User.java
 * Represents a registered user and handles validation, registration,
 * and login logic for the Registration and Login feature.
 */
public class User {

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellNumber;

    private boolean registered;
    private boolean loginSuccessful;

    // ---------- Constructors ----------

    public User() {
    }

    public User(String firstName, String lastName, String username, String password, String cellNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
    }

    // ---------- Getters and Setters ----------

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCellNumber() {
        return cellNumber;
    }

    public void setCellNumber(String cellNumber) {
        this.cellNumber = cellNumber;
    }

    public boolean isRegistered() {
        return registered;
    }

    // ---------- Validation Methods ----------

    /**
     * Checks that the username contains an underscore and is
     * no more than five characters long.
     */
    public boolean checkUserName() {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    /**
     * Checks that the password meets complexity requirements:
     * at least eight characters, a capital letter, a number,
     * and a special character.
     */
    public boolean checkPasswordComplexity() {
        if (password == null) {
            return false;
        }
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]).{8,}$";
        return password.matches(regex);
    }

    /**
     * Checks that the cell phone number contains the South African
     * international country code (+27) followed by the number,
     * with a total length of no more than ten characters after the code.
     * Example valid number: +27838968976
     */
    public boolean checkCellPhoneNumber() {
        if (cellNumber == null) {
            return false;
        }
        String regex = "^\\+27[0-9]{7,9}$";
        return cellNumber.matches(regex);
    }

    // ---------- Registration ----------

    /**
     * Validates username, password, and cell number and returns
     * the appropriate message. Sets registered = true only if all
     * three checks pass.
     */
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that "
                    + "your username contains an underscore and is no more "
                    + "than five characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that "
                    + "the password contains at least eight characters, a "
                    + "capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell number is incorrectly formatted or does not contain "
                    + "an international code; please correct the number and "
                    + "try again.";
        }

        registered = true;
        return "User " + firstName + " " + lastName + " registered successfully.";
    }

    // ---------- Login ----------

    /**
     * Verifies that the entered username and password match the
     * stored credentials for a registered user.
     */
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        loginSuccessful = registered
                && username != null
                && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);
        return loginSuccessful;
    }

    /**
     * Returns the messaging for a successful or failed login attempt.
     * Should be called after loginUser().
     */
    public String returnLoginStatus() {
        if (loginSuccessful) {
            return "Welcome " + firstName + ", " + lastName + ", it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}