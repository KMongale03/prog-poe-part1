/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationloginapp;

/**
 *
 * @author Student
 */
import User.User;
import java.util.Scanner;

/**
 * Main.java
 * Console driver for the Registration and Login feature.
 * Collects user input, registers the user, and handles login attempts.
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        User user = new User();

        System.out.println("=== User Registration ===");

        System.out.print("Enter first name: ");
        user.setFirstName(scanner.nextLine());

        System.out.print("Enter last name: ");
        user.setLastName(scanner.nextLine());

        System.out.print("Enter username (must contain '_' and be <= 5 characters): ");
        user.setUsername(scanner.nextLine());

        System.out.print("Enter password (8+ chars, capital, number, special char): ");
        user.setPassword(scanner.nextLine());

        System.out.print("Enter cell number (e.g. +27838968976): ");
        user.setCellNumber(scanner.nextLine());

        String registrationResult = user.registerUser();
        System.out.println(registrationResult);

        if (!user.isRegistered()) {
            System.out.println("Registration failed. Please restart and correct the details above.");
            scanner.close();
            return;
        }

        System.out.println("\n=== Login ===");
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        user.loginUser(loginUsername, loginPassword);
        System.out.println(user.returnLoginStatus());

        scanner.close();
    }
}